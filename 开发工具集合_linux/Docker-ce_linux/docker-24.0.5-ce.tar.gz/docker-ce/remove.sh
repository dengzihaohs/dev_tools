#!/usr/bin/env bash

# root用户执行
[ "$(id -u)" != "0" ] && { echo "Error: You must be root to run this script"; exit 1; }

# 脚本路径
SCRIPT_PATH="$( dirname "$( readlink -f "$0")")"

# 安装路径
install_path='/usr/local/docker'

printf "\n开始卸载...\n"

# 停止服务
systemctl disable docker.service &>/dev/null
systemctl stop docker &>/dev/null

# 删除服务名
/bin/rm -rf /lib/systemd/system/docker.service &>/dev/null
systemctl daemon-reload &>/dev/null

# 清理原有 DOCKER_HOME 相关环境变量
sed -i "/DOCKER_HOME/d" /etc/profile

# 匹配二进制文件
BINARY_FILES_PATH="$(find "${install_path}"/bin/ -type f )"

# 为二进制文件做短链接
echo "${BINARY_FILES_PATH}" | while read line; do
    # 获取文件名
    BINARY_FILES_NAME="$(basename "${line}" )"
    # 短链接
    /bin/rm -rf /usr/bin/"${BINARY_FILES_NAME:?}" 
done

# 解决 oci runtime error
# 在升级新引擎后,可能存在旧的 runtime 管理的json文件差异导致启动失败
# 删除旧容器的 runtime 管理的配置文件
if [ -d /run/docker/runtime-runc ]; then
    # 此目录下文件在 runtime 管理时会自动重新生成
    /bin/rm -rf /run/docker/runtime-runc/* &>/dev/null
fi

# 删除安装目录
/bin/rm -rf "${install_path:?}"

# 删除配置文件
/bin/rm -rf /etc/docker/daemon.json &>/dev/null

printf "已完成卸载\n"

exit 0

