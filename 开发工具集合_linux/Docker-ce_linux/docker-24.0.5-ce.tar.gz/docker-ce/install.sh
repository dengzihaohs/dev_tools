#!/bin/bash

# 脚本描述:
# 1. 以 root 用户安装并运行 docker 服务
#

# root用户执行
[ "$(id -u)" != "0" ] && { echo "Error: You must be root to run this script"; exit 1; }

# 安装路径
INSTALL_PATH='/usr/local/docker'

# 运行组名: 默认docker
DOCKER_GROUP='docker'

# 脚本路径
SCRIPT_PATH="$( dirname "$( readlink -f "$0")")"

# 创建安装安装目录
mkdir -p "${INSTALL_PATH}"/{bin,etc}

# 获取安装包
DOCKER_FILE="$(basename "$(find "${SCRIPT_PATH}"/* -name "docker*" -type f | grep 'tgz' | head -1)" )"

printf "\n开始解压文件...\n"

# 解压到指定路径下
tar -xvf "${SCRIPT_PATH}"/"${DOCKER_FILE}" -C "${INSTALL_PATH}"/bin/ --strip-component=1

# 复制 docker-compose
/bin/cp -rf "${SCRIPT_PATH}"/docker-compose "${INSTALL_PATH}"/bin/

printf "\n开始配置服务...\n"

# 创建配置文件目录
mkdir -p /etc/docker/

# 复制配置文件
/bin/cp -rf "${SCRIPT_PATH}"/daemon.json /etc/docker/

# 添加服务管理
/bin/cp -rf "${SCRIPT_PATH}"/docker.service /lib/systemd/system/

# 修改启动的二进制文件路径 
sed -i "s@/usr@${INSTALL_PATH}@g" /lib/systemd/system/docker.service

# 赋权
chmod +x /lib/systemd/system/docker.service

# 创建组
groupadd "${DOCKER_GROUP}" &>/dev/null

# 将用户添加到组中
usermod -aG "${DOCKER_GROUP}" root

# 赋予安装权限
chown root:root -Rf "${INSTALL_PATH}"
chmod 755 -Rf "${INSTALL_PATH}"

# 匹配二进制文件
BINARY_FILES_PATH="$(find "${INSTALL_PATH}"/bin/ -type f )"

# 为二进制文件做短链接
echo "${BINARY_FILES_PATH}" | while read line; do
    # 获取文件名
    BINARY_FILES_NAME="$(basename "${line}" )"
    # 短链接
    ln -sf "${line}" /usr/bin/"${BINARY_FILES_NAME}"
done

# 添加防火墙策略,避免启动失败
if ! grep 'not running' <<< "$(firewall-cmd --state)" 1>/dev/null; then
	firewall-cmd --permanent --zone=docker --change-interface=docker0 1>/dev/null
	firewall-cmd --reload 1>/dev/null
fi

# 配置运行环境变量
if [ -f "${INSTALL_PATH}"/bin/docker ]; then
    # 清理原有 DOCKER_HOME 相关环境变量
    sed -i "/DOCKER_HOME/d" /etc/profile

    # 设置DOCKER_HOME目录路径
    if ! grep 'DOCKER_HOME' /etc/profile | grep "${INSTALL_PATH}" 1>/dev/null; then
        printf "export DOCKER_HOME=%s\n" "${INSTALL_PATH}" >> /etc/profile
    fi

    # 设置二进制可执行文件路径,例如: docker 等命令 
    if ! grep 'DOCKER_HOME/sbin' /etc/profile 1>/dev/null; then
        printf "export PATH=\$PATH:\$DOCKER_HOME/bin\n" >> /etc/profile
    fi

    source /etc/profile &>/dev/null
fi

# 启动服务
systemctl daemon-reload &>/dev/null
systemctl enable docker.service &>/dev/null
systemctl start docker.service &>/dev/null

# 回显版本信息
printf "\ndocker-ce version: \n\n%s\n\n" "$(docker version)"  

exit 0

